function updatePreview() {
    document.getElementById("p-name").innerText =
        document.querySelector("[name='name']").value || "Your Name";

    document.getElementById("p-contact").innerText =
        (document.querySelector("[name='email']").value || "Email")
        + " | " +
        (document.querySelector("[name='phone']").value || "Phone");

    document.getElementById("p-skills").innerText =
        document.querySelector("[name='skills']").value || "Your skills here";

    document.getElementById("p-exp").innerText =
        document.querySelector("[name='experience']").value || "Your experience here";
}

function changeColor(color) {
    document.getElementById("resumeBox").style.borderLeftColor = color;
    document.getElementById("p-name").style.color = color;
    document.getElementById("theme_color").value = color;
}

document.querySelector("input[type=file]").addEventListener("change", function(e) {
    const reader = new FileReader();
    reader.onload = () => {
        document.getElementById("previewPhoto").src = reader.result;
    };
    reader.readAsDataURL(e.target.files[0]);
});
