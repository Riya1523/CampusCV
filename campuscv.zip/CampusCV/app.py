from flask import Flask, render_template, request, send_file
import pdfkit
import os

app = Flask(__name__)

BASE_DIR = os.path.abspath(os.path.dirname(__file__))
UPLOAD_FOLDER = os.path.join(BASE_DIR, "static", "uploads")
app.config["UPLOAD_FOLDER"] = UPLOAD_FOLDER

config = pdfkit.configuration(
    wkhtmltopdf=r"C:\Program Files\wkhtmltopdf\bin\wkhtmltopdf.exe"
)

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/generate", methods=["POST"])
def generate():
    data = request.form

    photo = request.files.get("photo")
    photo_path = ""

    if photo and photo.filename != "":
        save_path = os.path.join(app.config["UPLOAD_FOLDER"], photo.filename)
        photo.save(save_path)
        photo_path = "file:///" + save_path.replace("\\", "/")

    html = render_template(
        "resume.html",
        data=data,
        photo=photo_path
    )

    options = {
        "enable-local-file-access": ""
    }

    pdf_path = os.path.join(BASE_DIR, "resume.pdf")
    pdfkit.from_string(html, pdf_path, configuration=config, options=options)

    return send_file(pdf_path, as_attachment=True)

if __name__ == "__main__":
    os.makedirs(UPLOAD_FOLDER, exist_ok=True)
    app.run(debug=True)
